<?php

$lang['title_citations'] = "Citations";
$lang['title'] = "Title";
$lang['subtitle'] = "Subtitle";
$lang['volume'] = "Volume";
$lang['issue'] = "Issue";
$lang['edition'] = "Edition";
$lang['page_numbers'] = "Page numbers";
$lang['isbn'] = "ISBN";
$lang['provide_link_to_document'] = "Provide link to the document";
$lang['related_studies'] = "Related studies";
$lang['add_related_studies'] = "Add related studies";
$lang['select_studies'] = "Select studies";
$lang['add_new_citation'] = "Add New Citation";
$lang['edit_citation'] = "Edit Citation";


$lang['select_citation_type'] = "Select citation type";
$lang['first_name'] = "First name";
$lang['last_name'] = "Last name";
$lang['middle_initial'] = "Middle initial";

$lang['publisher'] = "Publisher";
$lang['publication_day_month_year'] = "Publication (Day/Month/Year)";
$lang['publication_city'] = "City";
$lang['publication_state_country'] = "Country/State";
$lang['citation_type'] = "Type";

$lang['authors'] = "Author(s)";

$lang['citation_information'] = "Citation Information";
$lang['related_studies'] = "Related Studies";
/* End of file citation_lang.php */
/* Location: ./system/language/english/citations_lang.php */