<?php
$lang['dashboard'] = "Dashboard";
$lang['nada_news_updates'] = "NADA News & Updates";
$lang['users'] = "Users";
$lang['database_backup'] = "Database Backup";
$lang['cache_files'] = "Cache Files";
$lang['report_bug'] = "Report Bug/Feature/Request";
$lang['reporter_name'] = "Name";
$lang['reporter_email'] = "Email";
$lang['subject'] = "Subject";
$lang['bug_request_description'] = "Provide detailed description of the bug/feature";




/* End of file dashboard_lang.php */
/* Location: ./system/language/english/dashboard_lang.php */